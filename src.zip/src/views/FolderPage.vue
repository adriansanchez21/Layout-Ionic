<template>
  <ion-page>
    <ion-header>
        <ion-toolbar>
            <ion-title>Hello Header</ion-title>
        </ion-toolbar>
    </ion-header>
    <ion-content class="ion-padding">
        <h1>Hello Content</h1>
    </ion-content>
    <ion-footer>
        <ion-title>Hello Footer</ion-title>
    </ion-footer>
  </ion-page>
</template>

<script setup lang="ts">
import { IonPage, IonHeader, IonContent, IonFooter, IonToolbar, IonTitle } from '@ionic/vue';
</script>

<style scoped>

</style>
