<template>
    <ion-page>
      <ion-header>
          <ion-toolbar>
              <ion-title>Library</ion-title>
          </ion-toolbar>
      </ion-header>
      <ion-content class="ion-padding">
          <h1>View de Library.vue</h1>
      </ion-content>
    </ion-page>
  </template>
  
  <script setup lang="ts">
  import { IonPage, IonHeader, IonContent, IonToolbar, IonTitle } from '@ionic/vue';
  </script>
  
  <style scoped>
  
  </style>
  